create definer = root@localhost view emp_view as
select `sample`.`employee`.`EMPNO`    AS `Employee_Number`,
       `sample`.`employee`.`FIRSTNME` AS `First_Name`,
       `sample`.`employee`.`MIDINIT`  AS `Middle_Initial`
from `sample`.`employee`
order by `sample`.`employee`.`EMPNO`;

