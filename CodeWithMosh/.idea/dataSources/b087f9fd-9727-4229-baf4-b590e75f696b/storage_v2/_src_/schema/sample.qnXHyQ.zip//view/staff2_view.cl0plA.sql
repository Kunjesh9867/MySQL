create definer = root@localhost view staff2_view as
select max(`sample`.`staff`.`SALARY`) AS `MAX(SALARY)`, `sample`.`staff`.`DEPT` AS `DEPT`
from `sample`.`staff`
group by `sample`.`staff`.`DEPT`;

