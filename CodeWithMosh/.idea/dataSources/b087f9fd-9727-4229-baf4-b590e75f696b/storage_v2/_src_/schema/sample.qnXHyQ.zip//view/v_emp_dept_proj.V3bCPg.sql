create definer = root@localhost view v_emp_dept_proj as
select `sample`.`employee`.`EMPNO`    AS `EMPNO`,
       `sample`.`employee`.`FIRSTNME` AS `FIRSTNME`,
       `sample`.`employee`.`LASTNAME` AS `LASTNAME`,
       `sample`.`employee`.`WORKDEPT` AS `WORKDEPT`,
       `sample`.`employee`.`SALARY`   AS `SALARY`,
       `sample`.`empprojact`.`ACTNO`  AS `ACTNO`,
       `sample`.`project`.`PROJNO`    AS `projno`,
       `sample`.`project`.`PROJNAME`  AS `projname`
from ((`sample`.`employee` join `sample`.`empprojact`
       on ((`sample`.`employee`.`EMPNO` = `sample`.`empprojact`.`EMPNO`))) join `sample`.`project`
      on ((`sample`.`project`.`PROJNO` = `sample`.`empprojact`.`PROJNO`)))
where (`sample`.`employee`.`SALARY` < 100000);

