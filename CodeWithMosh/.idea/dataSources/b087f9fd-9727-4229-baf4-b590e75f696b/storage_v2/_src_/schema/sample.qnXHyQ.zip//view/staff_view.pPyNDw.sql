create definer = root@localhost view staff_view as
select max(`sample`.`staff`.`SALARY`) AS `MAX(SALARY)`, max(`sample`.`staff`.`DEPT`) AS `MAX(DEPT)`
from `sample`.`staff`;

